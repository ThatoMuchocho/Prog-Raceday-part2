using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;

namespace RaceDay.Api.Services;

public class RouteService(RaceDayDbContext db)
{
    public async Task<(int Status, object? Body)> GetAsync(int eventId)
    {
        var route = await db.RouteInformation.AsNoTracking()
            .SingleOrDefaultAsync(x => x.EventID == eventId);
        return route is null ? (404, null) : (200, route);
    }

    public async Task<(int Status, object? Body)> UpsertAsync(int eventId, RouteRequest request)
    {
        if (!await db.Events.AnyAsync(x => x.EventID == eventId))
            return (404, new { message = "Event was not found." });

        var route = await db.RouteInformation.SingleOrDefaultAsync(x => x.EventID == eventId);
        if (route is null)
        {
            route = new RouteInformation { EventID = eventId };
            db.RouteInformation.Add(route);
        }

        route.RouteName = request.RouteName.Trim();
        route.RouteUrl = request.RouteUrl;
        route.RouteDescription = request.RouteDescription;
        await db.SaveChangesAsync();
        return (200, route);
    }

    public async Task<(int Status, object? Body)> DeleteAsync(int eventId)
    {
        var route = await db.RouteInformation.SingleOrDefaultAsync(x => x.EventID == eventId);
        if (route is null)
            return (404, null);

        db.RouteInformation.Remove(route);
        await db.SaveChangesAsync();
        return (204, null);
    }
}
