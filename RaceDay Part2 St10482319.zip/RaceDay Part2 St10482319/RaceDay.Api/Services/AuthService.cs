using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;

namespace RaceDay.Api.Services;

public class AuthService(RaceDayDbContext db, IConfiguration config)
{
    public async Task<(int Status, object Body)> RegisterAsync(RegisterRequest request)
    {
        var email = request.Email.Trim().ToLowerInvariant();
        if (await db.Users.AnyAsync(x => x.Email == email))
            return (409, new { message = "Email already registered." });

        var role = await db.Roles.SingleOrDefaultAsync(x => x.RoleName == "Participant");
        if (role is null)
            return (500, new { message = "Participant role is missing. Run the SQL script first." });

        var user = new User
        {
            FirstName = request.FirstName.Trim(),
            LastName = request.LastName.Trim(),
            Email = email,
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(request.Password),
            RoleID = role.RoleID,
            Role = role
        };

        db.Users.Add(user);
        await db.SaveChangesAsync();
        return (200, BuildAuthResponse(user));
    }

    public async Task<(int Status, object Body)> LoginAsync(LoginRequest request)
    {
        var email = request.Email.Trim().ToLowerInvariant();
        var user = await db.Users.Include(x => x.Role)
            .SingleOrDefaultAsync(x => x.Email == email && x.IsActive);

        if (user is null || !PasswordMatches(user.PasswordHash, request.Password))
            return (401, new { message = "Invalid email or password." });

        return (200, BuildAuthResponse(user));
    }

    public AuthResponse BuildAuthResponse(User user)
    {
        var role = user.Role?.RoleName ?? "Participant";
        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, user.UserID.ToString()),
            new Claim(ClaimTypes.Name, user.Email),
            new Claim(ClaimTypes.Role, role)
        };

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(config["Jwt:Key"]!));
        var hours = int.TryParse(config["Jwt:ExpiryHours"], out var parsed) ? parsed : 8;
        var token = new JwtSecurityToken(
            config["Jwt:Issuer"],
            config["Jwt:Audience"],
            claims,
            expires: DateTime.UtcNow.AddHours(hours),
            signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256));

        return new AuthResponse(user.UserID, user.FirstName, user.LastName, user.Email, role, new JwtSecurityTokenHandler().WriteToken(token));
    }

    private static bool PasswordMatches(string storedHash, string password)
    {
        if (string.IsNullOrWhiteSpace(storedHash) || storedHash.StartsWith("DEMO_HASH", StringComparison.OrdinalIgnoreCase))
            return false;

        try
        {
            return BCrypt.Net.BCrypt.Verify(password, storedHash);
        }
        catch
        {
            return false;
        }
    }
}
