using System.Text.Json;
using RaceDay.Api.DTOs;

namespace RaceDay.Api.Services;

public interface IWeatherService
{
    Task<WeatherResponse?> GetAsync(string location, CancellationToken cancellationToken = default);
}

public class OpenMeteoWeatherService(HttpClient http) : IWeatherService
{
    private static readonly Dictionary<string, (decimal Lat, decimal Lon, string Label)> Cities = new(StringComparer.OrdinalIgnoreCase)
    {
        ["johannesburg"] = (-26.2041m, 28.0473m, "Johannesburg"),
        ["soweto"] = (-26.2678m, 27.8585m, "Soweto"),
        ["durban"] = (-29.8587m, 31.0218m, "Durban"),
        ["cape town"] = (-33.9249m, 18.4241m, "Cape Town"),
        ["capetown"] = (-33.9249m, 18.4241m, "Cape Town"),
        ["pietermaritzburg"] = (-29.6006m, 30.3794m, "Pietermaritzburg"),
        ["nelspruit"] = (-25.4753m, 30.9694m, "Nelspruit"),
        ["mbombela"] = (-25.4753m, 30.9694m, "Mbombela"),
        ["pretoria"] = (-25.7479m, 28.2293m, "Pretoria"),
        ["port elizabeth"] = (-33.9608m, 25.6022m, "Gqeberha"),
        ["gqeberha"] = (-33.9608m, 25.6022m, "Gqeberha")
    };

    public async Task<WeatherResponse?> GetAsync(string location, CancellationToken cancellationToken = default)
    {
        if (!Cities.TryGetValue(location.Trim(), out var city))
            return null;

        var url = $"https://api.open-meteo.com/v1/forecast?latitude={city.Lat}&longitude={city.Lon}&current_weather=true";
        using var response = await http.GetAsync(url, cancellationToken);
        response.EnsureSuccessStatusCode();

        await using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);
        using var doc = await JsonDocument.ParseAsync(stream, cancellationToken: cancellationToken);
        var current = doc.RootElement.GetProperty("current_weather");
        var temp = current.GetProperty("temperature").GetDecimal();
        var wind = current.GetProperty("windspeed").GetDecimal();
        var code = current.GetProperty("weathercode").GetInt32();

        return new WeatherResponse(city.Label, city.Lat, city.Lon, temp, wind, Describe(code), "Open-Meteo");
    }

    private static string Describe(int code) => code switch
    {
        0 => "Clear",
        1 or 2 => "Partly cloudy",
        3 => "Overcast",
        45 or 48 => "Fog",
        51 or 53 or 55 => "Drizzle",
        61 or 63 or 65 => "Rain",
        71 or 73 or 75 => "Snow",
        80 or 81 or 82 => "Rain showers",
        95 => "Thunderstorm",
        _ => "Mixed conditions"
    };
}
