using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.Models;

namespace RaceDay.Api.Services;

public class EnrolmentService(RaceDayDbContext db)
{
    public async Task<(int Status, object? Body)> EnterAsync(int participantId, int eventCategoryId)
    {
        var slot = await db.EventCategories
            .Include(x => x.Event)
            .Include(x => x.Enrolments)
            .SingleOrDefaultAsync(x => x.EventCategoryID == eventCategoryId);

        if (slot is null)
            return (404, new { message = "Event category was not found." });

        if (slot.Event is null || !AppRules.CanAcceptEntries(slot.Event.Status))
            return (400, new { message = "This event is not open for entries." });

        var alreadyEntered = await db.Enrolments.AnyAsync(x =>
            x.ParticipantID == participantId &&
            x.EventCategoryID == eventCategoryId &&
            x.Status != "Cancelled");

        if (alreadyEntered)
            return (409, new { message = "You are already entered in this category." });

        var currentCount = slot.Enrolments.Count(x => x.Status != "Cancelled");
        if (currentCount >= slot.MaxParticipants)
            return (400, new { message = "This category is full." });

        var enrolment = new Enrolment
        {
            ParticipantID = participantId,
            EventCategoryID = eventCategoryId,
            Status = "Confirmed",
            PaymentStatus = slot.EntryFee == 0 ? "Paid" : "Pending"
        };

        db.Enrolments.Add(enrolment);
        await db.SaveChangesAsync();
        return (201, enrolment);
    }

    public Task<List<Enrolment>> MineAsync(int participantId) =>
        db.Enrolments.AsNoTracking()
            .Include(x => x.EventCategory)!.ThenInclude(x => x!.Event)
            .Include(x => x.EventCategory)!.ThenInclude(x => x!.Category)
            .Include(x => x.Result)
            .Where(x => x.ParticipantID == participantId)
            .OrderByDescending(x => x.EnrolmentDate)
            .ToListAsync();

    public Task<List<Enrolment>> AllAsync() =>
        db.Enrolments.AsNoTracking()
            .Include(x => x.Participant)
            .Include(x => x.EventCategory)!.ThenInclude(x => x!.Event)
            .Include(x => x.EventCategory)!.ThenInclude(x => x!.Category)
            .OrderByDescending(x => x.EnrolmentDate)
            .ToListAsync();

    public Task<List<Enrolment>> ForEventAsync(int eventId) =>
        db.Enrolments.AsNoTracking()
            .Include(x => x.Participant)
            .Include(x => x.EventCategory)!.ThenInclude(x => x!.Category)
            .Where(x => x.EventCategory!.EventID == eventId)
            .ToListAsync();

    public async Task<(int Status, object? Body)> CancelOwnAsync(int enrolmentId, int participantId)
    {
        var enrolment = await db.Enrolments.SingleOrDefaultAsync(x => x.EnrolmentID == enrolmentId);
        if (enrolment is null)
            return (404, null);

        if (enrolment.ParticipantID != participantId)
            return (403, new { message = "You can only cancel your own enrolment." });

        if (enrolment.Status == "Cancelled")
            return (400, new { message = "Enrolment is already cancelled." });

        enrolment.Status = "Cancelled";
        await db.SaveChangesAsync();
        return (204, null);
    }
}
