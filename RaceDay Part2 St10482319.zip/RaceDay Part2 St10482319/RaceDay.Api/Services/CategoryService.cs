using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;

namespace RaceDay.Api.Services;

public class CategoryService(RaceDayDbContext db)
{
    public Task<List<Category>> ListAsync() =>
        db.Categories.AsNoTracking().OrderBy(x => x.CategoryName).ToListAsync();

    public async Task<(int Status, object? Body)> CreateAsync(CategoryRequest request)
    {
        if (!AppRules.IsValidCategoryType(request.CategoryType))
            return (400, new { message = "Category type must be Run, Walk or Cycle." });

        var name = request.CategoryName.Trim();
        if (await db.Categories.AnyAsync(x => x.CategoryName == name))
            return (409, new { message = "A category with that name already exists." });

        var category = new Category
        {
            CategoryName = name,
            CategoryType = request.CategoryType,
            Description = request.Description,
            IsActive = request.IsActive
        };
        db.Categories.Add(category);
        await db.SaveChangesAsync();
        return (201, category);
    }

    public async Task<(int Status, object? Body)> UpdateAsync(int id, CategoryRequest request)
    {
        var category = await db.Categories.FindAsync(id);
        if (category is null)
            return (404, null);

        if (!AppRules.IsValidCategoryType(request.CategoryType))
            return (400, new { message = "Category type must be Run, Walk or Cycle." });

        category.CategoryName = request.CategoryName.Trim();
        category.CategoryType = request.CategoryType;
        category.Description = request.Description;
        category.IsActive = request.IsActive;
        await db.SaveChangesAsync();
        return (204, null);
    }

    public async Task<(int Status, object? Body)> DeleteAsync(int id)
    {
        var category = await db.Categories.FindAsync(id);
        if (category is null)
            return (404, null);

        if (await db.EventCategories.AnyAsync(x => x.CategoryID == id))
        {
            category.IsActive = false;
            await db.SaveChangesAsync();
            return (200, new { message = "Category is in use, so it was deactivated instead of deleted." });
        }

        db.Categories.Remove(category);
        await db.SaveChangesAsync();
        return (204, null);
    }

    public Task<List<EventCategory>> ForEventAsync(int eventId) =>
        db.EventCategories.AsNoTracking()
            .Include(x => x.Category)
            .Where(x => x.EventID == eventId)
            .ToListAsync();

    public async Task<(int Status, object? Body)> AttachAsync(int eventId, EventCategoryRequest request)
    {
        if (!await db.Events.AnyAsync(x => x.EventID == eventId))
            return (404, new { message = "Event was not found." });

        if (!await db.Categories.AnyAsync(x => x.CategoryID == request.CategoryID && x.IsActive))
            return (400, new { message = "Category was not found or is inactive." });

        if (await db.EventCategories.AnyAsync(x => x.EventID == eventId && x.CategoryID == request.CategoryID))
            return (409, new { message = "That category is already linked to this event." });

        var link = new EventCategory
        {
            EventID = eventId,
            CategoryID = request.CategoryID,
            EntryFee = request.EntryFee,
            MaxParticipants = request.MaxParticipants
        };
        db.EventCategories.Add(link);
        await db.SaveChangesAsync();
        return (201, link);
    }

    public async Task<(int Status, object? Body)> DetachAsync(int eventId, int eventCategoryId)
    {
        var link = await db.EventCategories.SingleOrDefaultAsync(x =>
            x.EventID == eventId && x.EventCategoryID == eventCategoryId);

        if (link is null)
            return (404, null);

        if (await db.Enrolments.AnyAsync(x => x.EventCategoryID == eventCategoryId && x.Status != "Cancelled"))
            return (409, new { message = "Cannot remove a category that already has active enrolments." });

        db.EventCategories.Remove(link);
        await db.SaveChangesAsync();
        return (204, null);
    }
}
