namespace RaceDay.Api.Services;

public static class AppRules
{
    public static readonly string[] EventStatuses = ["Upcoming", "Open", "Closed", "Completed", "Cancelled"];
    public static readonly string[] CategoryTypes = ["Run", "Walk", "Cycle"];
    public static readonly string[] EnrolmentStatuses = ["Pending", "Confirmed", "Cancelled"];

    public static bool IsValidEventStatus(string status) =>
        EventStatuses.Contains(status, StringComparer.OrdinalIgnoreCase);

    public static bool IsValidCategoryType(string type) =>
        CategoryTypes.Contains(type, StringComparer.OrdinalIgnoreCase);

    public static bool CanAcceptEntries(string eventStatus) =>
        eventStatus.Equals("Open", StringComparison.OrdinalIgnoreCase)
        || eventStatus.Equals("Upcoming", StringComparison.OrdinalIgnoreCase);
}
