using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;

namespace RaceDay.Api.Services;

public class EventService(RaceDayDbContext db)
{
    public Task<List<EventSummary>> ListAsync() =>
        db.Events.AsNoTracking()
            .OrderBy(x => x.EventDate)
            .Select(x => new EventSummary(x.EventID, x.EventName, x.Description, x.EventDate, x.Location, x.DistanceKm, x.Status))
            .ToListAsync();

    public Task<Event?> GetAsync(int id) =>
        db.Events.AsNoTracking()
            .Include(x => x.EventCategories).ThenInclude(x => x.Category)
            .Include(x => x.RouteInformation)
            .SingleOrDefaultAsync(x => x.EventID == id);

    public async Task<(int Status, object? Body)> CreateAsync(EventRequest request, int organiserId)
    {
        var error = Validate(request);
        if (error is not null)
            return (400, new { message = error });

        var entity = Map(new Event { CreatedBy = organiserId }, request);
        db.Events.Add(entity);
        await db.SaveChangesAsync();
        return (201, entity);
    }

    public async Task<(int Status, object? Body)> UpdateAsync(int id, EventRequest request)
    {
        var entity = await db.Events.FindAsync(id);
        if (entity is null)
            return (404, null);

        var error = Validate(request, checkPastDate: false);
        if (error is not null)
            return (400, new { message = error });

        Map(entity, request);
        await db.SaveChangesAsync();
        return (204, null);
    }

    public async Task<(int Status, object? Body)> DeleteAsync(int id)
    {
        var entity = await db.Events.FindAsync(id);
        if (entity is null)
            return (404, null);

        var hasEnrolments = await db.Enrolments.AnyAsync(x => x.EventCategory!.EventID == id);
        if (hasEnrolments)
            return (409, new { message = "Cannot delete an event that already has enrolments." });

        db.Events.Remove(entity);
        await db.SaveChangesAsync();
        return (204, null);
    }

    private static string? Validate(EventRequest request, bool checkPastDate = true)
    {
        if (!AppRules.IsValidEventStatus(request.Status))
            return "Invalid event status. Use Upcoming, Open, Closed, Completed or Cancelled.";

        if (checkPastDate && request.EventDate < DateOnly.FromDateTime(DateTime.UtcNow))
            return "Event date cannot be in the past.";

        return null;
    }

    private static Event Map(Event entity, EventRequest request)
    {
        entity.EventName = request.EventName.Trim();
        entity.Description = request.Description;
        entity.EventDate = request.EventDate;
        entity.Location = request.Location.Trim();
        entity.DistanceKm = request.DistanceKm;
        entity.StartTime = request.StartTime;
        entity.EndTime = request.EndTime;
        entity.Status = request.Status;
        return entity;
    }
}
