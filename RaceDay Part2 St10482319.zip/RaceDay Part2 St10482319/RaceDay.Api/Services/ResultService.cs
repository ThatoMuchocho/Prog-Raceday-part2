using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs;
using RaceDay.Api.Models;

namespace RaceDay.Api.Services;

public class ResultService(RaceDayDbContext db)
{
    public async Task<(int Status, object? Body)> CaptureAsync(ResultRequest request)
    {
        var enrolment = await db.Enrolments
            .Include(x => x.Result)
            .SingleOrDefaultAsync(x => x.EnrolmentID == request.EnrolmentID);

        if (enrolment is null)
            return (404, new { message = "Enrolment was not found." });

        if (enrolment.Status != "Confirmed")
            return (400, new { message = "Results can only be captured for confirmed enrolments." });

        if (enrolment.Result is not null)
            return (409, new { message = "A result already exists for this enrolment. Use PUT to update it." });

        var result = new Result
        {
            EnrolmentID = request.EnrolmentID,
            Position = request.Position,
            FinishTime = request.FinishTime,
            ChipTime = request.ChipTime,
            Pace = request.Pace,
            IsOfficial = request.IsOfficial
        };

        db.Results.Add(result);
        await db.SaveChangesAsync();
        return (201, result);
    }

    public async Task<(int Status, object? Body)> UpdateAsync(int id, ResultRequest request)
    {
        var result = await db.Results.FindAsync(id);
        if (result is null)
            return (404, null);

        result.Position = request.Position;
        result.FinishTime = request.FinishTime;
        result.ChipTime = request.ChipTime;
        result.Pace = request.Pace;
        result.IsOfficial = request.IsOfficial;
        result.DateCaptured = DateTime.UtcNow;
        await db.SaveChangesAsync();
        return (204, null);
    }

    public Task<List<Result>> MineAsync(int participantId) =>
        db.Results.AsNoTracking()
            .Include(x => x.Enrolment)!.ThenInclude(x => x!.EventCategory)!.ThenInclude(x => x!.Event)
            .Include(x => x.Enrolment)!.ThenInclude(x => x!.EventCategory)!.ThenInclude(x => x!.Category)
            .Where(x => x.Enrolment!.ParticipantID == participantId)
            .OrderByDescending(x => x.DateCaptured)
            .ToListAsync();

    public Task<List<Result>> ForEventAsync(int eventId) =>
        db.Results.AsNoTracking()
            .Include(x => x.Enrolment)!.ThenInclude(x => x!.Participant)
            .Include(x => x.Enrolment)!.ThenInclude(x => x!.EventCategory)!.ThenInclude(x => x!.Category)
            .Where(x => x.Enrolment!.EventCategory!.EventID == eventId)
            .OrderBy(x => x.Position)
            .ToListAsync();
}
