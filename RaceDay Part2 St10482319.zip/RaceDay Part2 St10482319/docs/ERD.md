# RaceDay Entity Relationship Diagram

Relational design for the South African road running, walking and cycling event platform.

```mermaid
erDiagram
    Roles ||--o{ Users : assigns
    Users ||--o{ Events : creates
    Users ||--o{ Enrolments : makes
    Events ||--o{ EventCategories : offers
    Categories ||--o{ EventCategories : classified_as
    Events ||--o| RouteInformation : describes
    EventCategories ||--o{ Enrolments : receives
    Enrolments ||--o| Results : records

    Roles {
        int RoleID PK
        nvarchar RoleName
        nvarchar Description
    }
    Users {
        int UserID PK
        nvarchar FirstName
        nvarchar LastName
        nvarchar Email
        nvarchar PasswordHash
        int RoleID FK
        datetime2 CreatedAt
        bit IsActive
    }
    Events {
        int EventID PK
        nvarchar EventName
        nvarchar Description
        date EventDate
        nvarchar Location
        decimal DistanceKm
        time StartTime
        time EndTime
        nvarchar Status
        int CreatedBy FK
        datetime2 DateCreated
    }
    Categories {
        int CategoryID PK
        nvarchar CategoryName
        nvarchar CategoryType
        nvarchar Description
        bit IsActive
    }
    EventCategories {
        int EventCategoryID PK
        int EventID FK
        int CategoryID FK
        decimal EntryFee
        int MaxParticipants
    }
    Enrolments {
        int EnrolmentID PK
        int ParticipantID FK
        int EventCategoryID FK
        datetime2 EnrolmentDate
        nvarchar Status
        nvarchar PaymentStatus
    }
    Results {
        int ResultID PK
        int EnrolmentID FK
        int Position
        time FinishTime
        time ChipTime
        decimal Pace
        bit IsOfficial
        datetime2 DateCaptured
    }
    RouteInformation {
        int RouteID PK
        int EventID FK
        nvarchar RouteName
        nvarchar RouteUrl
        nvarchar RouteDescription
    }
```

## Cardinality notes

- One user has exactly one role (`Organiser` or `Participant`).
- An organiser can create many events. Events cannot exist without a creating user.
- An event offers many categories (for example 10 km and 21 km). A category can appear on many events.
- A participant enrols in a specific event category. The unique constraint `(ParticipantID, EventCategoryID)` prevents double entry.
- A result belongs to exactly one enrolment.
- Route information is optional and at most one record per event.

## Role-based data access (enforced in Part 2 API)

| Role | Can create/edit/delete events and categories | Capture results | View enrolments | Enter events | View own results |
| --- | --- | --- | --- | --- | --- |
| Organiser | Yes | Yes | All | No | N/A |
| Participant | No | No | Own only | Yes | Yes |
