# RaceDay RESTful API endpoint plan (Part 1 / Part 2)

Base URL: `https://localhost:7xxx/api`  
Authentication: JWT Bearer token after login.  
Public registration always creates a **Participant**. Organiser accounts are seeded (Jarred) or promoted in the database.

## Auth

| Method | Path | Auth | Role | Description |
| --- | --- | --- | --- | --- |
| POST | `/auth/register` | Anonymous | - | Create a participant account |
| POST | `/auth/login` | Anonymous | - | Return JWT |
| GET | `/auth/me` | Bearer | Any | Current user profile |

## Events

| Method | Path | Auth | Role | Description |
| --- | --- | --- | --- | --- |
| GET | `/events` | Anonymous | - | Browse upcoming and published events |
| GET | `/events/{id}` | Anonymous | - | Event details, categories and route |
| POST | `/events` | Bearer | Organiser | Create event |
| PUT | `/events/{id}` | Bearer | Organiser | Update event |
| DELETE | `/events/{id}` | Bearer | Organiser | Delete event if no enrolments exist |

## Categories

| Method | Path | Auth | Role | Description |
| --- | --- | --- | --- | --- |
| GET | `/categories` | Anonymous | - | List race categories (run / walk / cycle) |
| POST | `/categories` | Bearer | Organiser | Create category |
| PUT | `/categories/{id}` | Bearer | Organiser | Update category |
| DELETE | `/categories/{id}` | Bearer | Organiser | Soft-deactivate or delete unused category |

## Event categories (enter by selecting a category)

| Method | Path | Auth | Role | Description |
| --- | --- | --- | --- | --- |
| GET | `/events/{eventId}/categories` | Anonymous | - | Categories offered on an event |
| POST | `/events/{eventId}/categories` | Bearer | Organiser | Attach a category with fee and cap |
| DELETE | `/events/{eventId}/categories/{eventCategoryId}` | Bearer | Organiser | Remove a category from an event |

## Enrolments

| Method | Path | Auth | Role | Description |
| --- | --- | --- | --- | --- |
| POST | `/enrolments` | Bearer | Participant | Enter an event category |
| GET | `/enrolments/mine` | Bearer | Participant | Own enrolment history |
| GET | `/enrolments` | Bearer | Organiser | All enrolments |
| GET | `/enrolments/event/{eventId}` | Bearer | Organiser | Enrolments for one event |
| PUT | `/enrolments/{id}/cancel` | Bearer | Participant | Cancel own enrolment |

## Results

| Method | Path | Auth | Role | Description |
| --- | --- | --- | --- | --- |
| POST | `/results` | Bearer | Organiser | Capture a finish result |
| PUT | `/results/{id}` | Bearer | Organiser | Update a captured result |
| GET | `/results/mine` | Bearer | Participant | Personal performance history |
| GET | `/results/event/{eventId}` | Anonymous | - | Public event results |

## Route and weather (race-day preparation)

| Method | Path | Auth | Role | Description |
| --- | --- | --- | --- | --- |
| GET | `/events/{eventId}/route` | Anonymous | - | Route information |
| PUT | `/events/{eventId}/route` | Bearer | Organiser | Create or replace route |
| DELETE | `/events/{eventId}/route` | Bearer | Organiser | Remove route |
| GET | `/weather?location={city}` | Anonymous | - | Live weather for a South African city |

## HTTP conventions

- `201 Created` for successful creates where a new resource id is returned.
- `204 No Content` for successful updates/deletes with no body.
- `400 Bad Request` for business-rule failures.
- `401 Unauthorized` when JWT is missing or invalid.
- `403 Forbidden` when the role cannot perform the action.
- `404 Not Found` when the resource id does not exist.
- `409 Conflict` for unique-constraint violations (duplicate email, duplicate enrolment).
