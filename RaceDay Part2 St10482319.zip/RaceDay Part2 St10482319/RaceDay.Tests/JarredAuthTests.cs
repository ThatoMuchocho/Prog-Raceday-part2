using Microsoft.EntityFrameworkCore;
using RaceDay.Api.DTOs;
using RaceDay.Api.Services;

namespace RaceDay.Tests;

public class JarredAuthTests
{
    [Fact]
    public async Task Register_always_assigns_participant_never_organiser()
    {
        await using var db = TestHarness.CreateDatabase();
        var auth = new AuthService(db, TestHarness.CreateConfig());

        var (status, body) = await auth.RegisterAsync(new RegisterRequest("Sipho", "Dlamini", "sipho@raceday.co.za", "Sipho@1234"));

        Assert.Equal(200, status);
        var response = Assert.IsType<AuthResponse>(body);
        Assert.Equal("Participant", response.Role);
        Assert.False(string.IsNullOrWhiteSpace(response.Token));
        Assert.Equal("Participant", await db.Users.Where(x => x.Email == "sipho@raceday.co.za").Select(x => x.Role!.RoleName).SingleAsync());
    }

    [Fact]
    public async Task Register_rejects_duplicate_email()
    {
        await using var db = TestHarness.CreateDatabase();
        var auth = new AuthService(db, TestHarness.CreateConfig());
        await TestHarness.SeedJarredWorldAsync(db);

        var (status, _) = await auth.RegisterAsync(new RegisterRequest("Jarred", "Clone", "jarred@raceday.co.za", "Jarred@123!"));

        Assert.Equal(409, status);
    }

    [Fact]
    public async Task Jarred_can_log_in_as_organiser()
    {
        await using var db = TestHarness.CreateDatabase();
        var auth = new AuthService(db, TestHarness.CreateConfig());
        await TestHarness.SeedJarredWorldAsync(db);

        var (status, body) = await auth.LoginAsync(new LoginRequest("jarred@raceday.co.za", "Jarred@123!"));

        Assert.Equal(200, status);
        var response = Assert.IsType<AuthResponse>(body);
        Assert.Equal("Organiser", response.Role);
        Assert.Equal("Jarred", response.FirstName);
    }

    [Fact]
    public async Task Login_rejects_wrong_password_for_jarred()
    {
        await using var db = TestHarness.CreateDatabase();
        var auth = new AuthService(db, TestHarness.CreateConfig());
        await TestHarness.SeedJarredWorldAsync(db);

        var (status, _) = await auth.LoginAsync(new LoginRequest("jarred@raceday.co.za", "WrongPass1!"));

        Assert.Equal(401, status);
    }

    [Fact]
    public async Task Login_is_case_insensitive_on_email()
    {
        await using var db = TestHarness.CreateDatabase();
        var auth = new AuthService(db, TestHarness.CreateConfig());
        await TestHarness.SeedJarredWorldAsync(db);

        var (status, body) = await auth.LoginAsync(new LoginRequest("JARRED@RACEDAY.CO.ZA", "Jarred@123!"));

        Assert.Equal(200, status);
        Assert.Equal("Organiser", Assert.IsType<AuthResponse>(body).Role);
    }
}
