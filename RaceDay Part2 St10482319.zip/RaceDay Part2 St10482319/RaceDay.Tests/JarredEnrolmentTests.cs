using RaceDay.Api.Services;

namespace RaceDay.Tests;

public class JarredEnrolmentTests
{
    [Fact]
    public async Task Thabo_can_enter_jarreds_soweto_marathon_category()
    {
        await using var db = TestHarness.CreateDatabase();
        var seeded = await TestHarness.SeedJarredWorldAsync(db);
        var service = new EnrolmentService(db);

        var (status, body) = await service.EnterAsync(seeded.Thabo.UserID, seeded.Marathon.EventCategoryID);

        Assert.Equal(201, status);
        Assert.NotNull(body);

        var mine = await service.MineAsync(seeded.Thabo.UserID);
        Assert.Single(mine);
        Assert.Equal("Confirmed", mine[0].Status);
    }

    [Fact]
    public async Task Duplicate_entry_in_the_same_category_is_rejected()
    {
        await using var db = TestHarness.CreateDatabase();
        var seeded = await TestHarness.SeedJarredWorldAsync(db);
        var service = new EnrolmentService(db);
        await service.EnterAsync(seeded.Thabo.UserID, seeded.Marathon.EventCategoryID);

        var (status, _) = await service.EnterAsync(seeded.Thabo.UserID, seeded.Marathon.EventCategoryID);

        Assert.Equal(409, status);
    }

    [Fact]
    public async Task Closed_event_does_not_accept_entries()
    {
        await using var db = TestHarness.CreateDatabase();
        var seeded = await TestHarness.SeedJarredWorldAsync(db);
        seeded.Soweto.Status = "Closed";
        await db.SaveChangesAsync();

        var (status, _) = await new EnrolmentService(db).EnterAsync(seeded.Thabo.UserID, seeded.Marathon.EventCategoryID);

        Assert.Equal(400, status);
    }

    [Fact]
    public async Task Category_cap_blocks_a_third_runner_when_jarred_set_max_to_two()
    {
        await using var db = TestHarness.CreateDatabase();
        var seeded = await TestHarness.SeedJarredWorldAsync(db);
        var service = new EnrolmentService(db);
        var extra = new RaceDay.Api.Models.User
        {
            FirstName = "Lerato",
            LastName = "Khumalo",
            Email = "lerato@raceday.co.za",
            PasswordHash = "hash",
            RoleID = seeded.Thabo.RoleID
        };
        var extra2 = new RaceDay.Api.Models.User
        {
            FirstName = "Pieter",
            LastName = "Botha",
            Email = "pieter@raceday.co.za",
            PasswordHash = "hash",
            RoleID = seeded.Thabo.RoleID
        };
        db.Users.AddRange(extra, extra2);
        await db.SaveChangesAsync();

        Assert.Equal(201, (await service.EnterAsync(seeded.Thabo.UserID, seeded.Marathon.EventCategoryID)).Status);
        Assert.Equal(201, (await service.EnterAsync(extra.UserID, seeded.Marathon.EventCategoryID)).Status);
        Assert.Equal(400, (await service.EnterAsync(extra2.UserID, seeded.Marathon.EventCategoryID)).Status);
    }

    [Fact]
    public async Task Participant_cannot_cancel_someone_elses_enrolment()
    {
        await using var db = TestHarness.CreateDatabase();
        var seeded = await TestHarness.SeedJarredWorldAsync(db);
        var service = new EnrolmentService(db);
        var created = await service.EnterAsync(seeded.Thabo.UserID, seeded.Marathon.EventCategoryID);
        var enrolment = Assert.IsType<RaceDay.Api.Models.Enrolment>(created.Body);

        var (status, _) = await service.CancelOwnAsync(enrolment.EnrolmentID, seeded.Jarred.UserID);

        Assert.Equal(403, status);
    }

    [Fact]
    public async Task Thabo_can_cancel_his_own_entry()
    {
        await using var db = TestHarness.CreateDatabase();
        var seeded = await TestHarness.SeedJarredWorldAsync(db);
        var service = new EnrolmentService(db);
        var created = await service.EnterAsync(seeded.Thabo.UserID, seeded.Marathon.EventCategoryID);
        var enrolment = Assert.IsType<RaceDay.Api.Models.Enrolment>(created.Body);

        var (status, _) = await service.CancelOwnAsync(enrolment.EnrolmentID, seeded.Thabo.UserID);

        Assert.Equal(204, status);
    }

    [Fact]
    public async Task Organiser_list_includes_thabos_entry_on_jarreds_event()
    {
        await using var db = TestHarness.CreateDatabase();
        var seeded = await TestHarness.SeedJarredWorldAsync(db);
        var service = new EnrolmentService(db);
        await service.EnterAsync(seeded.Thabo.UserID, seeded.Marathon.EventCategoryID);

        var all = await service.ForEventAsync(seeded.Soweto.EventID);

        Assert.Single(all);
        Assert.Equal(seeded.Thabo.UserID, all[0].ParticipantID);
    }
}
