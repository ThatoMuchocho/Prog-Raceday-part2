using System.ComponentModel.DataAnnotations;
using RaceDay.Api.DTOs;
using RaceDay.Api.Services;

namespace RaceDay.Tests;

public class ValidationTests
{
    [Fact]
    public void Register_rejects_invalid_email()
    {
        var request = new RegisterRequest("Jarred", "LovesTests", "not-an-email", "Password123!");
        Assert.False(IsValid(request));
    }

    [Fact]
    public void Register_rejects_short_password()
    {
        var request = new RegisterRequest("Jarred", "LovesTests", "jarred@raceday.co.za", "short");
        Assert.False(IsValid(request));
    }

    [Fact]
    public void Register_accepts_jarred_payload()
    {
        var request = new RegisterRequest("Jarred", "LovesTests", "jarred.tests@raceday.co.za", "Jarred@123!");
        Assert.True(IsValid(request));
    }

    [Theory]
    [InlineData(0)]
    [InlineData(-5)]
    public void Event_rejects_non_positive_distance(decimal distance)
    {
        var request = new EventRequest("Jarred Mile", null, new DateOnly(2027, 1, 1), "Durban", distance, null, null, "Open");
        Assert.False(IsValid(request));
    }

    [Fact]
    public void Event_accepts_comrades_style_distance()
    {
        var request = new EventRequest("Comrades", "Down run", new DateOnly(2027, 6, 6), "Pietermaritzburg", 89.9m, new TimeOnly(5, 30), null, "Open");
        Assert.True(IsValid(request));
    }

    [Fact]
    public void Login_rejects_invalid_email()
    {
        Assert.False(IsValid(new LoginRequest("jarred-at-raceday", "Jarred@123!")));
    }

    [Fact]
    public void Enrolment_rejects_zero_category_id()
    {
        Assert.False(IsValid(new EnrolmentRequest(0)));
    }

    [Theory]
    [InlineData("Upcoming")]
    [InlineData("Open")]
    [InlineData("Closed")]
    [InlineData("Completed")]
    [InlineData("Cancelled")]
    public void AppRules_accepts_known_event_statuses(string status)
    {
        Assert.True(AppRules.IsValidEventStatus(status));
    }

    [Fact]
    public void AppRules_rejects_unknown_event_status()
    {
        Assert.False(AppRules.IsValidEventStatus("JarredSpecial"));
    }

    [Theory]
    [InlineData("Run")]
    [InlineData("Walk")]
    [InlineData("Cycle")]
    public void AppRules_accepts_sa_road_event_types(string type)
    {
        Assert.True(AppRules.IsValidCategoryType(type));
    }

    [Theory]
    [InlineData("Open", true)]
    [InlineData("Upcoming", true)]
    [InlineData("Closed", false)]
    [InlineData("Cancelled", false)]
    [InlineData("Completed", false)]
    public void AppRules_only_open_or_upcoming_events_accept_entries(string status, bool expected)
    {
        Assert.Equal(expected, AppRules.CanAcceptEntries(status));
    }

    private static bool IsValid(object value) =>
        Validator.TryValidateObject(value, new ValidationContext(value), new List<ValidationResult>(), true);
}
