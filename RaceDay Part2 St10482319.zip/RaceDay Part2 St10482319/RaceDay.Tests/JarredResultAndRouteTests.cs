using RaceDay.Api.DTOs;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Tests;

public class JarredResultAndRouteTests
{
    [Fact]
    public async Task Jarred_can_capture_thabos_finish_time()
    {
        await using var db = TestHarness.CreateDatabase();
        var seeded = await TestHarness.SeedJarredWorldAsync(db);
        var enrolments = new EnrolmentService(db);
        var created = await enrolments.EnterAsync(seeded.Thabo.UserID, seeded.Marathon.EventCategoryID);
        var enrolment = Assert.IsType<Enrolment>(created.Body);

        var (status, body) = await new ResultService(db).CaptureAsync(new ResultRequest(
            enrolment.EnrolmentID, 12, new TimeOnly(3, 28, 10), new TimeOnly(3, 27, 55), 4.95m, true));

        Assert.Equal(201, status);
        Assert.NotNull(body);
    }

    [Fact]
    public async Task Duplicate_result_for_same_enrolment_is_rejected()
    {
        await using var db = TestHarness.CreateDatabase();
        var seeded = await TestHarness.SeedJarredWorldAsync(db);
        var enrolments = new EnrolmentService(db);
        var created = await enrolments.EnterAsync(seeded.Thabo.UserID, seeded.Marathon.EventCategoryID);
        var enrolment = Assert.IsType<Enrolment>(created.Body);
        var results = new ResultService(db);
        await results.CaptureAsync(new ResultRequest(enrolment.EnrolmentID, 1, new TimeOnly(3, 0, 0), null, 4.2m));

        var (status, _) = await results.CaptureAsync(new ResultRequest(enrolment.EnrolmentID, 2, new TimeOnly(3, 1, 0), null, 4.3m));

        Assert.Equal(409, status);
    }

    [Fact]
    public async Task Results_are_not_captured_for_cancelled_entries()
    {
        await using var db = TestHarness.CreateDatabase();
        var seeded = await TestHarness.SeedJarredWorldAsync(db);
        var enrolments = new EnrolmentService(db);
        var created = await enrolments.EnterAsync(seeded.Thabo.UserID, seeded.Marathon.EventCategoryID);
        var enrolment = Assert.IsType<Enrolment>(created.Body);
        await enrolments.CancelOwnAsync(enrolment.EnrolmentID, seeded.Thabo.UserID);

        var (status, _) = await new ResultService(db).CaptureAsync(new ResultRequest(enrolment.EnrolmentID, 1, new TimeOnly(3, 0, 0), null, 4.2m));

        Assert.Equal(400, status);
    }

    [Fact]
    public async Task Thabo_can_read_his_personal_performance_history()
    {
        await using var db = TestHarness.CreateDatabase();
        var seeded = await TestHarness.SeedJarredWorldAsync(db);
        var enrolments = new EnrolmentService(db);
        var created = await enrolments.EnterAsync(seeded.Thabo.UserID, seeded.Marathon.EventCategoryID);
        var enrolment = Assert.IsType<Enrolment>(created.Body);
        var results = new ResultService(db);
        await results.CaptureAsync(new ResultRequest(enrolment.EnrolmentID, 12, new TimeOnly(3, 28, 10), null, 4.95m));

        var mine = await results.MineAsync(seeded.Thabo.UserID);
        Assert.Single(mine);
        Assert.Equal(12, mine[0].Position);
    }

    [Fact]
    public async Task Jarred_can_publish_route_information_for_soweto()
    {
        await using var db = TestHarness.CreateDatabase();
        var seeded = await TestHarness.SeedJarredWorldAsync(db);
        var routes = new RouteService(db);

        var (status, _) = await routes.UpsertAsync(seeded.Soweto.EventID, new RouteRequest(
            "Nasrec to FNB Stadium",
            "https://maps.example.com/soweto",
            "Jarred's official RaceDay route notes."));

        Assert.Equal(200, status);
        Assert.Equal(200, (await routes.GetAsync(seeded.Soweto.EventID)).Status);
    }

    [Fact]
    public async Task Missing_route_returns_404()
    {
        await using var db = TestHarness.CreateDatabase();
        var seeded = await TestHarness.SeedJarredWorldAsync(db);

        Assert.Equal(404, (await new RouteService(db).GetAsync(seeded.Soweto.EventID)).Status);
    }

    [Fact]
    public async Task Jarred_can_add_a_walk_category_and_attach_it()
    {
        await using var db = TestHarness.CreateDatabase();
        var seeded = await TestHarness.SeedJarredWorldAsync(db);
        var categories = new CategoryService(db);

        var created = await categories.CreateAsync(new CategoryRequest("Community Walk", "Walk", "5 km walk"));
        Assert.Equal(201, created.Status);
        var category = Assert.IsType<Category>(created.Body);

        var attached = await categories.AttachAsync(seeded.Soweto.EventID, new EventCategoryRequest(category.CategoryID, 80m, 500));
        Assert.Equal(201, attached.Status);
    }

    [Fact]
    public async Task Invalid_category_type_is_rejected()
    {
        await using var db = TestHarness.CreateDatabase();
        await TestHarness.SeedJarredWorldAsync(db);

        var (status, _) = await new CategoryService(db).CreateAsync(new CategoryRequest("Triathlon", "Swim", null));
        Assert.Equal(400, status);
    }
}
