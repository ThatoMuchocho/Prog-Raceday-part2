using RaceDay.Api.DTOs;
using RaceDay.Api.Services;

namespace RaceDay.Tests;

public class JarredEventTests
{
    [Fact]
    public async Task Jarred_can_create_a_community_race()
    {
        await using var db = TestHarness.CreateDatabase();
        var seeded = await TestHarness.SeedJarredWorldAsync(db);
        var service = new EventService(db);

        var (status, body) = await service.CreateAsync(new EventRequest(
            "Jarred Park Run",
            "Saturday community run",
            new DateOnly(2027, 2, 14),
            "Nelspruit",
            5m,
            new TimeOnly(8, 0),
            new TimeOnly(10, 0),
            "Open"), seeded.Jarred.UserID);

        Assert.Equal(201, status);
        Assert.NotNull(body);
    }

    [Fact]
    public async Task Create_rejects_past_event_dates()
    {
        await using var db = TestHarness.CreateDatabase();
        var seeded = await TestHarness.SeedJarredWorldAsync(db);
        var service = new EventService(db);

        var (status, _) = await service.CreateAsync(new EventRequest(
            "Historic Comrades",
            null,
            new DateOnly(2019, 6, 9),
            "Durban",
            89m,
            null,
            null,
            "Open"), seeded.Jarred.UserID);

        Assert.Equal(400, status);
    }

    [Fact]
    public async Task Create_rejects_invalid_status()
    {
        await using var db = TestHarness.CreateDatabase();
        var seeded = await TestHarness.SeedJarredWorldAsync(db);
        var service = new EventService(db);

        var (status, _) = await service.CreateAsync(new EventRequest(
            "Mystery Race",
            null,
            new DateOnly(2027, 3, 1),
            "Cape Town",
            10m,
            null,
            null,
            "Maybe"), seeded.Jarred.UserID);

        Assert.Equal(400, status);
    }

    [Fact]
    public async Task List_returns_soweto_marathon_created_by_jarred()
    {
        await using var db = TestHarness.CreateDatabase();
        await TestHarness.SeedJarredWorldAsync(db);
        var service = new EventService(db);

        var events = await service.ListAsync();

        Assert.Contains(events, x => x.EventName == "Soweto Marathon" && x.Location.Contains("Soweto"));
    }

    [Fact]
    public async Task Delete_is_blocked_when_jarred_event_has_enrolments()
    {
        await using var db = TestHarness.CreateDatabase();
        var seeded = await TestHarness.SeedJarredWorldAsync(db);
        var enrolments = new EnrolmentService(db);
        await enrolments.EnterAsync(seeded.Thabo.UserID, seeded.Marathon.EventCategoryID);

        var (status, _) = await new EventService(db).DeleteAsync(seeded.Soweto.EventID);

        Assert.Equal(409, status);
    }

    [Fact]
    public async Task Delete_succeeds_when_nobody_has_entered()
    {
        await using var db = TestHarness.CreateDatabase();
        var seeded = await TestHarness.SeedJarredWorldAsync(db);

        var (status, _) = await new EventService(db).DeleteAsync(seeded.Soweto.EventID);

        Assert.Equal(204, status);
        Assert.Null(await new EventService(db).GetAsync(seeded.Soweto.EventID));
    }

    [Fact]
    public async Task Update_returns_404_for_unknown_event()
    {
        await using var db = TestHarness.CreateDatabase();
        await TestHarness.SeedJarredWorldAsync(db);

        var (status, _) = await new EventService(db).UpdateAsync(999, new EventRequest(
            "Ghost Race", null, new DateOnly(2027, 1, 1), "Pretoria", 10m, null, null, "Open"));

        Assert.Equal(404, status);
    }
}
