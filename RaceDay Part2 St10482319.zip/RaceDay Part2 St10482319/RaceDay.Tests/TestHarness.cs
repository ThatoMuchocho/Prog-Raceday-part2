using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using RaceDay.Api.Data;
using RaceDay.Api.Models;
using RaceDay.Api.Services;

namespace RaceDay.Tests;

internal static class TestHarness
{
    public const string JwtKey = "RaceDay-PROG6212-ChangeThisKey-32chars!";

    public static RaceDayDbContext CreateDatabase()
    {
        var options = new DbContextOptionsBuilder<RaceDayDbContext>()
            .UseInMemoryDatabase($"RaceDay-{Guid.NewGuid()}")
            .Options;

        var db = new RaceDayDbContext(options);
        db.Database.EnsureCreated();
        return db;
    }

    public static IConfiguration CreateConfig() =>
        new ConfigurationBuilder()
            .AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["Jwt:Key"] = JwtKey,
                ["Jwt:Issuer"] = "RaceDay.Api",
                ["Jwt:Audience"] = "RaceDay.Clients",
                ["Jwt:ExpiryHours"] = "8"
            })
            .Build();

    public static async Task<(User Jarred, User Thabo, Event Soweto, EventCategory Marathon)> SeedJarredWorldAsync(RaceDayDbContext db)
    {
        var organiserRole = await db.Roles.SingleAsync(x => x.RoleName == "Organiser");
        var participantRole = await db.Roles.SingleAsync(x => x.RoleName == "Participant");

        var jarred = new User
        {
            FirstName = "Jarred",
            LastName = "Lecturer",
            Email = "jarred@raceday.co.za",
            PasswordHash = BCrypt.Net.BCrypt.HashPassword("Jarred@123!"),
            RoleID = organiserRole.RoleID,
            Role = organiserRole
        };
        var thabo = new User
        {
            FirstName = "Thabo",
            LastName = "Mokoena",
            Email = "thabo@raceday.co.za",
            PasswordHash = BCrypt.Net.BCrypt.HashPassword("Jarred@123!"),
            RoleID = participantRole.RoleID,
            Role = participantRole
        };
        db.Users.AddRange(jarred, thabo);
        await db.SaveChangesAsync();

        var marathon = new Category { CategoryName = "42 KM Marathon", CategoryType = "Run", Description = "Full marathon" };
        var tenK = new Category { CategoryName = "10 KM Run", CategoryType = "Run", Description = "Ten kilometres" };
        db.Categories.AddRange(marathon, tenK);
        await db.SaveChangesAsync();

        var soweto = new Event
        {
            EventName = "Soweto Marathon",
            Description = "Jarred's flagship RaceDay event",
            EventDate = new DateOnly(2026, 11, 1),
            Location = "Soweto, Gauteng",
            DistanceKm = 42.2m,
            Status = "Open",
            CreatedBy = jarred.UserID
        };
        db.Events.Add(soweto);
        await db.SaveChangesAsync();

        var slot = new EventCategory
        {
            EventID = soweto.EventID,
            CategoryID = marathon.CategoryID,
            EntryFee = 450m,
            MaxParticipants = 2
        };
        db.EventCategories.Add(slot);
        await db.SaveChangesAsync();

        return (jarred, thabo, soweto, slot);
    }
}
